FILE_PATHS = {
    'local': {
        'basics': './data/tp/title_basics.tsv',
        'ratings': './data/tp/title_ratings.tsv'
        },
    # 'cloud':{
    #     'basics': 'gs://edc_bootamp_data/data/title_basics.tsv',
    #     'ratings': 'gs://edc_bootamp_data/data/title_ratings.tsv',
    # }
}


# SAVE_PATH = {
#     'local': './data/imdb/title_basics_with_rating',
#     # 'cloud': 'gs://edc_bootamp_data/data/title_basics_with_rating',
# }